//
//  ViewController.swift
//  Baddam_UniversityApp
//
//  Created by Baddam,Asritha on 4/17/23.
//

import UIKit

class UniversityArray{
    var domain : String?
    
    
    init(domain: String){
        self.domain = domain
        
    }
}

class UniversitiesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Universities_Array.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
                var myCell = universitiesTableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
                //populate a cell with data
                myCell.textLabel?.text = Universities_Array[indexPath.row].domain
                
                //return a cell
                return myCell
    }
    
    
    
    
    
    var Universities_Array = UniversitiesArray
    
    
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Domains"
        // Do any additional setup after loading the view.
        universitiesTableView.delegate = self
        universitiesTableView.dataSource = self
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
                if(transition == "listsSegue"){
                    let destination = segue.destination as! UniversityListViewController
                    
                    //send the selected product row
                    destination.UniversityListArray = Universities_Array[(universitiesTableView.indexPathForSelectedRow?.row)!].UniversityLists
                    destination.title = Universities_Array[(universitiesTableView.indexPathForSelectedRow?.row)!].domain
                }
            }
    }




