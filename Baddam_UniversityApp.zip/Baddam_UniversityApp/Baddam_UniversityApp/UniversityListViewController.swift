//
//  UniversityListViewController.swift
//  Baddam_UniversityApp
//
//  Created by Baddam,Asritha on 4/17/23.
//

import UIKit


class UniversityListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UniversityListArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create a cell
        var myCell = universityListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        //populate a cell with data
        myCell.textLabel?.text = UniversityListArray[indexPath.row]?.collegeName
                
        //return a cell
        return myCell
    }
    
    
   
    var UniversityListArray:[UniversityList?] = []
    
   
    
  
    @IBOutlet weak var universityListTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        universityListTableView.delegate = self
        universityListTableView.dataSource = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if(transition == "universityInfoSegue"){
            let destination = segue.destination as! UniversityInfoViewController
            
            
            destination.destinationImage = UniversityListArray[(universityListTableView.indexPathForSelectedRow?.row)!]!.collegeImage
            destination.destinationInfo = UniversityListArray[(universityListTableView.indexPathForSelectedRow?.row)!]!.collegeInfo
            destination.title = UniversityListArray[(universityListTableView.indexPathForSelectedRow?.row)!]!.collegeName
        }
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
