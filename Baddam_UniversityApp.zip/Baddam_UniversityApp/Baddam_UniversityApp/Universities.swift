//
//  Universities.swift
//  Baddam_UniversityApp
//
//  Created by Baddam,Asritha on 4/17/23.
//

import Foundation
struct Universities {
    var domain = ""
    var UniversityLists:[UniversityList] = []
}

struct UniversityList{
    var collegeName = ""
    var collegeImage = ""
    var collegeInfo = ""
    
}

let u1 = Universities(domain: "Information Technology", UniversityLists:[
    UniversityList(collegeName: "Northwest Missouri State University, Maryville",collegeImage: "nwmsu",collegeInfo: "Northwest Missouri State University is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students."),
    UniversityList(collegeName: "University of Central Missouri, Kansas",collegeImage: "ucm",collegeInfo: "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries on its 1,561-acre campus."),
    UniversityList(collegeName: "George Mason University, Virginia",collegeImage: "gmu",collegeInfo: "George Mason University is a public research university in Fairfax County, Virginia, with an independent City of Fairfax postal address in the Washington metropolitan area."),
    UniversityList(collegeName: "University of Texas at Dallas, Dallas",collegeImage: "utd",collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas."),
    UniversityList(collegeName: "University of South Florida, Tampa",collegeImage: "usf",collegeInfo: "The University of South Florida is a public research university with its main campus located in Tampa, Florida, and other campuses in St. Petersburg and Sarasota. It is one of 12 members of the State University System of Florida."),
    UniversityList(collegeName: "Florida International University, Florida", collegeImage: "fiu",collegeInfo: "Florida International University is a public research university with its main campus in the neighborhood of University Park in the Westchester census-designated place in the area of End in Miami-Dade County, Florida.")
])
let u2 = Universities(domain: "Computer Science", UniversityLists:[
    UniversityList(collegeName: "Columbia University, NewYork",collegeImage: "cu",collegeInfo: "Columbia University, officially titled as Columbia University in the City of New York, is a private Ivy League research university in New York City."),
    UniversityList(collegeName: "Duke University, Durham",collegeImage: "du",collegeInfo: "Duke University is a private research university in Durham, North Carolina. Founded by Methodists and Quakers in the present-day city of Trinity in 1838, the school moved to Durham in 1892."),
    UniversityList(collegeName: "Harvard University, Cambridge ",collegeImage: "hu",collegeInfo: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "Stanford University, Stanford",collegeImage: "su",collegeInfo: "Stanford University, officially Leland Stanford Junior University,is a private research university in Stanford, California."),
    UniversityList(collegeName: "University of Texas at Dallas, Dallas",collegeImage: "utd",collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas. It is one of the largest public universities in the Dallas area and the northernmost institution of the University of Texas system."),
    UniversityList(collegeName: "University of Central Missouri, Kansas",collegeImage: "ucm",collegeInfo: "The University of Central Missouri is a public university in Warrensburg, Missouri. In 2019, enrollment was 11,229 students from 49 states and 59 countries on its 1,561-acre campus.")
])
let u3 = Universities(domain: "Data Science and Analytics", UniversityLists:[
    UniversityList(collegeName: "Harvard University, Cambridge ",collegeImage: "hu",collegeInfo: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts."),
    UniversityList(collegeName: "George Mason University, Virginia",collegeImage: "gmu",collegeInfo: "George Mason University is a public research university in Fairfax County, Virginia, with an independent City of Fairfax postal address in the Washington metropolitan area."),
    UniversityList(collegeName: "Stanford University, Stanford",collegeImage: "su",collegeInfo: "Stanford University, officially Leland Stanford Junior University,is a private research university in Stanford, California."),
    UniversityList(collegeName: "University of Texas at Dallas, Dallas",collegeImage: "utd",collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas. It is one of the largest public universities in the Dallas area and the northernmost institution of the University of Texas system."),
    UniversityList(collegeName: "University of South Florida, Tampa",collegeImage: "usf",collegeInfo: "The University of South Florida is a public research university with its main campus located in Tampa, Florida, and other campuses in St. Petersburg and Sarasota."),
    UniversityList(collegeName: "Florida International University, Florida", collegeImage: "fiu",collegeInfo: "Florida International University is a public research university with its main campus in the neighborhood of University Park in the Westchester census-designated place in the area of End in Miami-Dade County, Florida.")
])
let u4 = Universities(domain: "Cyber Security", UniversityLists:[
    UniversityList(collegeName: "Duke University, Durham",collegeImage: "du",collegeInfo: "Duke University is a private research university in Durham, North Carolina. Founded by Methodists and Quakers in the present-day city of Trinity in 1838, the school moved to Durham in 1892."),
    UniversityList(collegeName: "Florida International University, Florida", collegeImage: "fiu",collegeInfo: "Florida International University is a public research university with its main campus in the neighborhood of University Park in the Westchester census-designated place in the unincorporated area of West End in Miami-Dade County, Florida."),
    UniversityList(collegeName: "Harvard University, Cambridge ",collegeImage: "hu",collegeInfo: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts. Founded in 1636 as Harvard College and named for its first benefactor, the Puritan clergyman John Harvard, it is the oldest institution of higher learning in the United States."),
    UniversityList(collegeName: "University of Texas at Dallas, Dallas",collegeImage: "utd",collegeInfo: "The University of Texas at Dallas is a public research university in Richardson, Texas. It is one of the largest public universities in the Dallas area and the northernmost institution of the University of Texas system."),
    UniversityList(collegeName: "University of South Florida, Tampa",collegeImage: "usf",collegeInfo: "The University of South Florida is a public research university with its main campus located in Tampa, Florida, and other campuses in St. Petersburg and Sarasota."),
    UniversityList(collegeName: "Florida International University, Florida",collegeImage: "fiu",collegeInfo: "Florida International University is a public research university with its main campus in the neighborhood of University Park in the Westchester census-designated place in the area of End in Miami-Dade County, Florida.")
])



/*UniversityList: ['Northwest Missouri State University', 'University of Central Missouri']*/

var UniversitiesArray:[Universities] = [u1,u2,u3,u4]
