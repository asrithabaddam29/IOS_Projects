//
//  UniversityInfoViewController.swift
//  Baddam_UniversityApp
//
//  Created by Baddam,Asritha on 4/17/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    
    
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var showInfoAction: UIButton!
    
    
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    
    var destinationImage = ""
    var destinationInfo = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        universityImageViewOutlet.frame.origin.x = view.frame.width
        
        universityImageViewOutlet.image = UIImage(named: destinationImage)
        
        universityInfoOutlet.isHidden = true
        
        UIView.animate(withDuration: 0.5, animations: {
        //Move all the compoenets to the center and disable show button
        self.universityImageViewOutlet.center.x = self.view.center.x
                           
            })
       
        
    }
    
    
    @IBAction func showBtnClicked(_ sender: UIButton) {
        //destinationImage = UniversitiesArray.collegeInfo
        
        universityInfoOutlet.isHidden = false
        universityInfoOutlet.text! = destinationInfo
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
