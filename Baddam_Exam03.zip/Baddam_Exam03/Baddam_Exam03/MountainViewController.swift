//
//  MountainViewController.swift
//  Baddam_Exam03
//
//  Created by Baddam,Asritha on 4/27/23.
//

import UIKit

class MountainViewController: UIViewController {
    
    
    @IBOutlet weak var mountainLabelOL: UILabel!
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    var mountainLabelDestination = ""
    var imageDestination = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageViewOL.image = UIImage(named: imageDestination)
        mountainLabelOL.text = mountainLabelDestination
    }
    
    
    
    @IBAction func animateBtn(_ sender: UIButton) {
        //making the current image opaque.
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.alpha = 0
        })
        //Assign the new image with animation and make it transparent. (alpha = 1)
        UIView.animate(withDuration: 2, delay:0.3, animations: {
            self.imageViewOL.alpha = 1
            self.imageViewOL.image = UIImage(named: self.imageDestination)
        })
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
