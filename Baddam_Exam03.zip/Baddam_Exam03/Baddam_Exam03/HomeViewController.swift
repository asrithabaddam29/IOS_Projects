//
//  ViewController.swift
//  Baddam_Exam03
//
//  Created by Baddam,Asritha on 4/27/23.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        mountainsArray.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var Cell = tableViewOL.dequeueReusableCell(withIdentifier: "mountainCell", for: indexPath)
                
        //populate a cell with data
        Cell.textLabel?.text = mountainsArray[indexPath.row].MountainName
                
        //return the cell
        return Cell
    }
    
    
    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var mountainsArray = Mountains
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableViewOL.delegate = self;
        tableViewOL.dataSource = self;
        self.title = "Mountains"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "mountainSegue"{
            
            let destination = segue.destination as! MountainViewController
            
            //send the selected product row
            
            destination.imageDestination = mountainsArray[(tableViewOL.indexPathForSelectedRow?.row)!].MountainImage
            
            destination.mountainLabelDestination = mountainsArray[(tableViewOL.indexPathForSelectedRow?.row)!].MountainName
        }
    }


}

