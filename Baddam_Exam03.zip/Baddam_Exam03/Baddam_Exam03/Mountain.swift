//
//  Mountain.swift
//  Baddam_Exam03
//
//  Created by Baddam,Asritha on 4/27/23.
//

import Foundation

struct Mountain{
    var MountainName = ""
    var MountainImage  = ""
   
    
}

let m1 = Mountain(MountainName:"Grand Teton",MountainImage:"grandTeton")

let m2 = Mountain(MountainName:"Denali",MountainImage:"denali")

let m3 = Mountain(MountainName:"Mount Shasta",MountainImage:"mountShasta")

let m4 = Mountain(MountainName:"Half Dome",MountainImage:"halfDome")

let m5 = Mountain(MountainName:"Mount Everest",MountainImage:"mountEverest")

let Mountains = [m1,m2,m3,m4,m5]
