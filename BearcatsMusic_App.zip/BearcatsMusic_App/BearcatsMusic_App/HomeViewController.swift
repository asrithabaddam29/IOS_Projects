//
//  ViewController.swift
//  BearcatsMusic_App
//
//  Created by Baddam,Asritha on 4/25/23.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var musicImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func beginButton(_ sender: UIButton) {
    }
    

}

