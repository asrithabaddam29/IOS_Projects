//
//
//  SelectInstrumentViewController.swift
//  BearcatsMusic_App
//
//  Created by Baddam,Asritha on 4/25/23.
//

import UIKit

class SelectInstrumentViewController: UIViewController {
    
    @IBOutlet weak var selectInstrumentLabel: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func pianoBtn(_ sender: UIButton) {
    }
    
    
    @IBAction func drumpadBtn(_ sender: UIButton) {
    }
    
    
    @IBAction func xylophoneBtn(_ sender: Any) {
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
