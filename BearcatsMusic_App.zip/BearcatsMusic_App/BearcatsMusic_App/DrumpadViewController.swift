//
//  DrumpadViewController.swift
//  BearcatsMusic_App
//
//  Created by Baddam,Asritha on 4/25/23.
//

import UIKit

import AVFoundation


class DrumpadViewController: UIViewController {
    
    var audioPlayer = AVAudioPlayer()
    
    
    @IBOutlet var keys: [UIButton]!
    
    let references = ["key1", "key2", "key3", "key4", "key5", "key6", "key7", "key8"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
       
    }
    
    
    @IBAction func keyPressed(_ sender: UIButton) {
        play(key: keys.index(of: sender)! + 1 )
    }
    
    
   
    
    func play(key: Int) {
           print(key,references[key - 1])
           let reference = references[key - 1]
           if let path = Bundle.main.path(forResource: reference, ofType: "wav") {
               let url = URL(fileURLWithPath: path)
               print(reference)
               do {
                   audioPlayer = try AVAudioPlayer(contentsOf: url)
                   audioPlayer.prepareToPlay()
                   audioPlayer.play()
                   
               }
               catch {
                   print(error)
               }
           }
       }
    
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
