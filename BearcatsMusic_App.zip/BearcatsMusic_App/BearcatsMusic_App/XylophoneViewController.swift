//
//  XylophoneViewController.swift
//  BearcatsMusic_App
//
//  Created by Baddam,Asritha on 4/25/23.
//

import UIKit

import AVFoundation

class XylophoneViewController: UIViewController {
    
    var audioPlayer = AVAudioPlayer()
    
    
    @IBOutlet var notes: [UIButton]!
    
    let references = ["note1", "note2", "note3", "note4", "note5", "note6", "note7"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func notePressed(_ sender: UIButton) {
        play(note: notes.index(of: sender)! + 1 )
    }
    
    
    func play(note: Int) {
            print(note,references[note - 1])
            let reference = references[note - 1]
            if let path = Bundle.main.path(forResource: reference, ofType: "wav") {
                let url = URL(fileURLWithPath: path)
                print(reference)
                do {
                    audioPlayer = try AVAudioPlayer(contentsOf: url)
                    audioPlayer.prepareToPlay()
                    audioPlayer.play()
                    
                }
                catch {
                    print(error)
                }
            }
        }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
