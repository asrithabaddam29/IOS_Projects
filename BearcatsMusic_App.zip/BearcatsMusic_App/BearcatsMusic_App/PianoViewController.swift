//
//  PianoViewController.swift
//  BearcatsMusic_App
//
//  Created by Baddam,Asritha on 4/25/23.
//

import UIKit

import AVFoundation

class PianoViewController: UIViewController {
    
    var audioPlayer = AVAudioPlayer()
    
    
    @IBOutlet var tiles: [UIButton]!
    
   
    
    let references = ["tile1", "tile2", "tile3", "tile4", "tile5", "tile6", "tile7", "tile8", "tile9", "tile10", "tile11", "tile12", "tile13"]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    
        
        
    }

    
    @IBAction func tilePressed(_ sender: UIButton) {
        play(tile: tiles.firstIndex(of: sender)! + 1 )
    }
    
  
        
       
    
    
    func play(tile: Int) {
            print(tile,references[tile - 1])
            let reference = references[tile - 1]
            if let path = Bundle.main.path(forResource: reference, ofType: "wav") {
                let url = URL(fileURLWithPath: path)
                print(reference)
                do {
                    audioPlayer = try AVAudioPlayer(contentsOf: url)
                    audioPlayer.prepareToPlay()
                    audioPlayer.play()
                    
                }
                catch {
                    print(error)
                }
            }
        }
    
    
    
    
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
